-- SQLite
SELECT * FROM OrderedGifts